<?php
/*
 *	Made by Samerton
 *  https://github.com/samerton
 *  NamelessMC version 2.0.0-pr5
 *
 *  License: MIT
 *
 *  Particles.js module for NamelessMC
 */

require_once(ROOT_PATH . '/modules/Particles/module.php');
$module = new Particles_Module();