<?php 
/*
 *	Made by Coldfire - https://coldfiredev.cf
 *  NamelessMC version 2.0.0-pr7
 *
 *  Module for Skyfall Template
 */
$skyfall_language = new Language(ROOT_PATH . '/modules/Skyfall/language', LANGUAGE);
if(!isset($admin_sidebar)) $admin_sidebar = array();
$admin_sidebar['skyfall'] = array(
	'title' => $skyfall_language->get('language', 'skyfall_title'),
	'url' => URL::build('/admin/skyfall')
);
require_once(ROOT_PATH . '/modules/Skyfall/module.php');
$module = new Skyfall_Module($pages, $language, $skyfall_language);