<?php

	if(!defined('THEME_GA'))
	define('THEME_GA', '');

	if(!defined('THEME_AL'))
	define('THEME_AL', 'yes');

	if(!defined('THEME_LINKS'))
	define('THEME_LINKS', 'gwh');

	if(!defined('THEME_TS'))
	define('THEME_TS', 'widget');

	if(!defined('THEME_DARK'))
	define('THEME_DARK', 'yes');

	if(!defined('THEME_CARD_ROUNDED'))
	define('THEME_CARD_ROUNDED', 'no');

	if(!defined('THEME_BG_HEIGHT'))
	define('THEME_BG_HEIGHT', '300px');

	if(!defined('THEME_BG_HEIGHT_M'))
	define('THEME_BG_HEIGHT_M', '250px');

	if(!defined('THEME_NAVBAR'))
	define('THEME_NAVBAR', 'double');

	if(!defined('THEME_L_BG'))
	define('THEME_L_BG', '/custom/templates/Skyfall/img/loginbg.png');

	if(!defined('THEME_E_BG'))
	define('THEME_E_BG', '/custom/templates/Skyfall/img/errorbg.jpg');

	if(!defined('THEME_R_BG'))
	define('THEME_R_BG', '/custom/templates/Skyfall/img/registerbg.jpg');

	if(!defined('THEME_ELR_LOGO'))
	define('THEME_ELR_LOGO', '250px');

	if(!defined('THEME_ELR_MARGIN'))
	define('THEME_ELR_MARGIN', '150px');

	if(!defined('THEME_WB_S1'))
	define('THEME_WB_S1', '003702b657a4445a955cfa7f24274e69');

	if(!defined('THEME_WB_S2'))
	define('THEME_WB_S2', '06440cef9a884036971298512c32a0f0');

	if(!defined('THEME_WB_S3'))
	define('THEME_WB_S3', 'c20e191bfe244416b94c70acf99ea327');

	if(!defined('THEME_WB_S4'))
	define('THEME_WB_S4', '106c04b856d74298bc0cbac6a35b47a0');

	if(!defined('THEME_WB_S5'))
	define('THEME_WB_S5', '1f1c1b59ecb3498a8d1125c2f69a8225');

	if(!defined('THEME_WB_S6'))
	define('THEME_WB_S6', 'e73d89adf8cb4b69b91d96594ae8585d');

	if(!defined('THEME_WB_T'))
	define('THEME_WB_T', 'Welcome to Skyfall!');

	if(!defined('THEME_WB_D'))
	define('THEME_WB_D', 'To join our community, please login or register!');

	if(!defined('THEME_WB_1N'))
	define('THEME_WB_1N', 'Login');

	if(!defined('THEME_WB_2N'))
	define('THEME_WB_2N', 'Register');

	if(!defined('THEME_WB_1L'))
	define('THEME_WB_1L', '/login');

	if(!defined('THEME_WB_2L'))
	define('THEME_WB_2L', '/register');

	if(!defined('THEME_ABOUT'))
	define('THEME_ABOUT', 'Skyfall is a very cool NamelessMC template and this is an example description!');

	if(!defined('THEME_OTHER_T'))
	define('THEME_OTHER_T', 'Store');

	if(!defined('THEME_OTHER_D'))
	define('THEME_OTHER_D', 'Visit our store today to check out some of the amazing items we have to offer!');

	if(!defined('THEME_OTHER_BT'))
	define('THEME_OTHER_BT', 'Visit Store');

	if(!defined('THEME_OTHER_BL'))
	define('THEME_OTHER_BL', 'https://store.hypixel.net');

	if(!defined('THEME_OTHER_BC'))
	define('THEME_OTHER_BC', '#0275d8');

	if(!defined('THEME_OTHER_BCH'))
	define('THEME_OTHER_BCH', '#025aa5');

	if(!defined('THEME_NEWS_BTN'))
	define('THEME_NEWS_BTN', 'yes');

	if(!defined('THEME_NEWS_LINK'))
	define('THEME_NEWS_LINK', '/forum/view/28-news/');

	if(!defined('THEME_LOGO_SIZE'))
	define('THEME_LOGO_SIZE', '250px');

	if(!defined('THEME_LOGO_SIZE_M'))
	define('THEME_LOGO_SIZE_M', '200px');

	if(!defined('THEME_LOGO_MARGIN'))
	define('THEME_LOGO_MARGIN', '-280px');

	if(!defined('THEME_LOGO_MARGIN_M'))
	define('THEME_LOGO_MARGIN_M', '-220px');

	if(!defined('THEME_C_OVERLAY'))
	define('THEME_C_OVERLAY', 'yes');

	if(!defined('THEME_FONT'))
	define('THEME_FONT', 'Montserrat');

	if(!defined('THEME_BOX_MARGIN'))
	define('THEME_BOX_MARGIN', '-160px');

	if(!defined('THEME_P_COLOR'))
	define('THEME_P_COLOR', '#326903');

	if(!defined('THEME_S_COLOR'))
	define('THEME_S_COLOR', '#325903');
	
	if(!defined('THEME_DISCORD_SERVER'))
	define('THEME_DISCORD_SERVER', 'discord.gg/example');

	if(!defined('THEME_BG'))
	define('THEME_BG', '/custom/templates/Skyfall/img/bg.jpg');

	if(!defined('THEME_ALERT_TITLE'))
	define('THEME_ALERT_TITLE', '');
	
	if(!defined('THEME_ALERT_TEXT'))
	define('THEME_ALERT_TEXT', 'This is a test alert! This message is configurable in StaffCP -> Skyfall');
	
	if(!defined('THEME_ANNOUNCE_TITLE'))
	define('THEME_ANNOUNCE_TITLE', '');
	
	if(!defined('THEME_ANNOUNCE_TEXT'))
	define('THEME_ANNOUNCE_TEXT', 'This is a test announcement! This message is configurable in StaffCP -> Skyfall');
	
	if(!defined('THEME_FAVICON'))
	define('THEME_FAVICON', '');

	if(!defined('THEME_DS_BOX'))
	define('THEME_DS_BOX', 'yes');

	if(!defined('THEME_LOGO'))
	define('THEME_LOGO', '');
	
	if(!defined('THEME_SLIDER1_TITLE'))
	define('THEME_SLIDER1_TITLE', '');
	
	if(!defined('THEME_SLIDER2_TITLE'))
	define('THEME_SLIDER2_TITLE', 'Slider #2');
	
	if(!defined('THEME_SLIDER3_TITLE'))
	define('THEME_SLIDER3_TITLE', 'Slider #3');
	
	if(!defined('THEME_SLIDER4_TITLE'))
	define('THEME_SLIDER4_TITLE', 'Slider #4');
	
	if(!defined('THEME_SLIDER5_TITLE'))
	define('THEME_SLIDER5_TITLE', 'Slider #5');
	
	if(!defined('THEME_SLIDER1_DESCRIPTION'))
	define('THEME_SLIDER1_DESCRIPTION', 'Configure this slider in StaffCP -> Skyfall');
	
	if(!defined('THEME_SLIDER2_DESCRIPTION'))
	define('THEME_SLIDER2_DESCRIPTION', 'Configure this slider in StaffCP -> Skyfall');
	
	if(!defined('THEME_SLIDER3_DESCRIPTION'))
	define('THEME_SLIDER3_DESCRIPTION', 'Configure this slider in StaffCP -> Skyfall');
	
	if(!defined('THEME_SLIDER4_DESCRIPTION'))
	define('THEME_SLIDER4_DESCRIPTION', 'Configure this slider in StaffCP -> Skyfall');
	
	if(!defined('THEME_SLIDER5_DESCRIPTION'))
	define('THEME_SLIDER5_DESCRIPTION', 'Configure this slider in StaffCP -> Skyfall');
	
	if(!defined('THEME_SLIDER1_IMAGE'))
	define('THEME_SLIDER1_IMAGE', '/custom/templates/Skyfall/img/slider.jpg');
	
	if(!defined('THEME_SLIDER2_IMAGE'))
	define('THEME_SLIDER2_IMAGE', '/custom/templates/Skyfall/img/slider.jpg');
	
	if(!defined('THEME_SLIDER3_IMAGE'))
	define('THEME_SLIDER3_IMAGE', '/custom/templates/Skyfall/img/slider.jpg');
	
	if(!defined('THEME_SLIDER4_IMAGE'))
	define('THEME_SLIDER4_IMAGE', '/custom/templates/Skyfall/img/slider.jpg');
	
	if(!defined('THEME_SLIDER5_IMAGE'))
	define('THEME_SLIDER5_IMAGE', '/custom/templates/Skyfall/img/slider.jpg');
	
	if(!defined('THEME_SLIDER1_LINK'))
	define('THEME_SLIDER1_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER2_LINK'))
	define('THEME_SLIDER2_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER3_LINK'))
	define('THEME_SLIDER3_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER4_LINK'))
	define('THEME_SLIDER4_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER5_LINK'))
	define('THEME_SLIDER5_LINK', 'https://google.com');
	
	if(!defined('PORTAL_1_LINK'))
	define('PORTAL_1_LINK', '/forum');
	
	if(!defined('PORTAL_2_LINK'))
	define('PORTAL_2_LINK', '/vote');
	
	if(!defined('PORTAL_3_LINK'))
	define('PORTAL_3_LINK', 'https://store.hypixel.net');
	
	if(!defined('PORTAL_1_ICON'))
	define('PORTAL_1_ICON', '/custom/templates/Skyfall/img/Forums.png');
	
	if(!defined('PORTAL_2_ICON'))
	define('PORTAL_2_ICON', '/custom/templates/Skyfall/img/Vote.png');
	
	if(!defined('PORTAL_3_ICON'))
	define('PORTAL_3_ICON', '/custom/templates/Skyfall/img/Shop.png');

	if(!defined('PORTAL_LOGO_SIZE'))
	define('PORTAL_LOGO_SIZE', '250px');

	if(!defined('PORTAL_LOGO_SIZE_M'))
	define('PORTAL_LOGO_SIZE_M', '200px');

	if(!defined('PORTAL_LOGO_MARGIN'))
	define('PORTAL_LOGO_MARGIN', '50px');

	if(!defined('PORTAL_LOGO_MARGIN_M'))
	define('PORTAL_LOGO_MARGIN_M', '25px');

	if(!defined('PORTAL_IMAGE_MARGIN'))
	define('PORTAL_IMAGE_MARGIN', '300px');

	if(!defined('PORTAL_IMAGE_MARGIN_M'))
	define('PORTAL_IMAGE_MARGIN_M', '250px');
	
	if(!defined('THEME_PORTAL_BG'))
	define('THEME_PORTAL_BG', 'custom/templates/Skyfall/img/portal-bg.png');

?>