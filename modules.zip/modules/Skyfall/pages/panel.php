<?php
/*
 *	Made by Coldfire - https://coldfiredev.cf
 *  NamelessMC version 2.0.0-pr7
 *
 *  Module for Skyfall Template - Panel Backend
 */

if($user->isLoggedIn()){
	if(!$user->canViewACP()){
		// No
		Redirect::to(URL::build('/'));
		die();
	}
	if(!$user->isAdmLoggedIn()){
		// Needs to authenticate
		Redirect::to(URL::build('/panel/auth'));
		die();
	} else {
		if($user->data()->group_id != 2 && !$user->hasPermission('admincp.skyfall')){
			require_once(ROOT_PATH . '/404.php');
			die();
		}
	}
} else {
	Redirect::to(URL::build('/login'));
	die();
}

define('PAGE', 'panel');
define('PARENT_PAGE', 'skyfall');
define('PANEL_PAGE', 'skyfall');
$page_title = $skyfall_language->get('language', 'skyfall_title');
require_once(ROOT_PATH . '/core/templates/backend_init.php');

if(isset($_POST['view'])){
	if(Token::check(Input::get('token'))){
		$view = $_POST['view'];
		$getFont = $_POST['font'];
		$getLinks = $_POST['links'];
		$getBG = $_POST['bg'];
		$getTS = $_POST['ts'];
		$getAL = $_POST['al'];
		$getCardRounded = $_POST['card_rounded'];
		$getDark = $_POST['dark'];
		$getBGHeight = $_POST['bg_height'];
		$getBGHeightM = $_POST['bg_height_m'];
		$getNavbar = $_POST['navbar'];
		$getEBG = $_POST['ebg'];
		$getLBG = $_POST['lbg'];
		$getRBG = $_POST['rbg'];
		$getELRLogo = $_POST['elr_logo'];
		$getELRMargin = $_POST['elr_margin'];
		$getWBs1 = $_POST['wb_s1'];
		$getWBs2 = $_POST['wb_s2'];
		$getWBs3 = $_POST['wb_s3'];
		$getWBs4 = $_POST['wb_s4'];
		$getWBs5 = $_POST['wb_s5'];
		$getWBs6 = $_POST['wb_s6'];
		$getWBt = $_POST['wb_t'];
		$getWBd = $_POST['wb_d'];
		$getWB1n = $_POST['wb_1n'];
		$getWB1l = $_POST['wb_1l'];
		$getWB2n = $_POST['wb_2n'];
		$getWB2l = $_POST['wb_2l'];
		$getAbout = $_POST['about'];
		$getOtherT = $_POST['other_t'];
		$getOtherD = $_POST['other_d'];
		$getOtherBT = $_POST['other_bt'];
		$getOtherBL = $_POST['other_bl'];
		$getOtherBC = $_POST['other_bc'];
		$getOtherBCH = $_POST['other_bch'];
		$getNewsBTN = $_POST['news_btn'];
		$getNewsLink = $_POST['news_link'];
		$getBoxMargin = $_POST['box_margin'];
		$getPortal1Icon = $_POST['portal1_icon'];
		$getPortal2Icon = $_POST['portal2_icon'];
		$getPortal3Icon = $_POST['portal3_icon'];
		$getPortal1Link = $_POST['portal1_link'];
		$getPortal2Link = $_POST['portal2_link'];
		$getPortal3Link = $_POST['portal3_link'];
		$getPortalLM = $_POST['portal_lm'];
		$getPortalLMM = $_POST['portal_lmm'];
		$getPortalIM = $_POST['portal_im'];
		$getPortalIMM = $_POST['portal_imm'];
		$getPortalLogoSize = $_POST['portal_logo'];
		$getPortalLogoSizeM = $_POST['portal_logo_m'];
		$getPortalBg = $_POST['portalbg'];
		$getLOGO = $_POST['logo']; 
		$getCOverlay = $_POST['coverlay'];
		$getGA = $_POST['ga'];
		$getP = $_POST['p_color'];
		$getS = $_POST['s_color'];
		$getLogoSize = $_POST['logo_size'];
		$getLogoSizeM = $_POST['logo_size_m'];
		$getLogoMargin = $_POST['logo_margin'];
		$getLogoMarginM = $_POST['logo_margin_m'];
		$getDiscordServer = $_POST['discord_server']; 
		$getFavicon = $_POST['favicon']; 
		$getAlertText = $_POST['alert_text']; 
		$getDSBox = $_POST['ds_box'];
		$getAlertTitle = $_POST['alert_title'];
		$getAnnounceText = $_POST['announce_text']; 
		$getAnnounceTitle = $_POST['announce_title'];
		$getSlider1Title = $_POST['slider1_title'];
		$getSlider1Desc = $_POST['slider1_desc'];
		$getSlider1Image = $_POST['slider1_image'];
		$getSlider1Link = $_POST['slider1_link'];
		$getSlider2Title = $_POST['slider2_title'];
		$getSlider2Desc = $_POST['slider2_desc'];
		$getSlider2Image = $_POST['slider2_image'];
		$getSlider2Link = $_POST['slider2_link'];
		$getSlider3Title = $_POST['slider3_title'];
		$getSlider3Desc = $_POST['slider3_desc'];
		$getSlider3Image = $_POST['slider3_image'];
		$getSlider3Link = $_POST['slider3_link'];
		$getSlider4Title = $_POST['slider4_title'];
		$getSlider4Desc = $_POST['slider4_desc'];
		$getSlider4Image = $_POST['slider4_image'];
		$getSlider4Link = $_POST['slider4_link'];
		$getSlider5Title = $_POST['slider5_title'];
		$getSlider5Desc = $_POST['slider5_desc'];
		$getSlider5Image = $_POST['slider5_image'];
		$getSlider5Link = $_POST['slider5_link'];
	} else
		$errors = array($language->get('general', 'invalid_token'));
} else
	$view = null;

if($view == "update"){
	$f = fopen(ROOT_PATH . "/modules/Skyfall/pages/settings.php","w");
	require ROOT_PATH . '/modules/Skyfall/pages/settings.default.php';

	if(fwrite($f, $settings_inf) > 0){
		fclose($f);

		Session::flash('skyfall_success', $skyfall_language->get('language', 'successfully_updated'));

		Redirect::to(URL::build('/panel/skyfall'));
		die();

	} else
		$errors = array($skyfall_language->get('language', 'unable_to_write_to_settings'));

}

Module::loadPage($user, $pages, $cache, $smarty, array($navigation, $cc_nav, $mod_nav), $widgets);

if(Session::exists('skyfall_success'))
	$success = Session::flash('skyfall_success');

if(isset($success))
	$smarty->assign(array(
		'SUCCESS' => $success,
		'SUCCESS_TITLE' => $language->get('general', 'success')
	));

if(isset($errors) && count($errors))
	$smarty->assign(array(
		'ERRORS' => $errors,
		'ERRORS_TITLE' => $language->get('general', 'error')
	));

require ROOT_PATH . '/modules/Skyfall/pages/settings.php';
$getNavbarBg = THEME_BG;
$getDark = THEME_DARK;
$getLinks = THEME_LINKS;
$getCardRounded = THEME_CARD_ROUNDED;
$getEBG = THEME_E_BG;
$getLBG = THEME_L_BG;
$getRBG = THEME_R_BG;
$getELRMargin = THEME_ELR_MARGIN;
$getELRLogo = THEME_ELR_LOGO;
$getGA = THEME_GA;
$getTS = THEME_TS;
$getAL = THEME_AL;
$getBGHeight = THEME_BG_HEIGHT;
$getBGHeightM = THEME_BG_HEIGHT_M;
$getNavbar = THEME_NAVBAR;
$getBoxMargin = THEME_BOX_MARGIN;
$getFont = THEME_FONT;
$getWBs1 = THEME_WB_S1;
$getWBs2 = THEME_WB_S2;
$getWBs3 = THEME_WB_S3;
$getWBs4 = THEME_WB_S4;
$getWBs5 = THEME_WB_S5;
$getWBs6 = THEME_WB_S6;
$getWBt = THEME_WB_T;
$getWBd = THEME_WB_D;
$getWB1n = THEME_WB_1N;
$getWB2n = THEME_WB_2N;
$getWB1l = THEME_WB_1L;
$getWB2l = THEME_WB_2L;
$getAbout = THEME_ABOUT;
$getOtherT = THEME_OTHER_T;
$getOtherD = THEME_OTHER_D;
$getOtherBT = THEME_OTHER_BT;
$getOtherBL = THEME_OTHER_BL;
$getOtherBC = THEME_OTHER_BC;
$getOtherBCH = THEME_OTHER_BCH;
$getNewsBTN = THEME_NEWS_BTN;
$getNewsLink = THEME_NEWS_LINK;
$getS = THEME_S_COLOR;
$getP = THEME_P_COLOR;
$getLogoSize = THEME_LOGO_SIZE;
$getLogoSizeM = THEME_LOGO_SIZE_M;
$getLogoMargin = THEME_LOGO_MARGIN;
$getLogoMarginM = THEME_LOGO_MARGIN_M;
$getCOverlay = THEME_C_OVERLAY;
$getPortalBg = THEME_PORTAL_BG;
$getPortal1Icon = PORTAL_1_ICON;
$getPortal2Icon = PORTAL_2_ICON;
$getPortal3Icon = PORTAL_3_ICON;
$getPortal1Link = PORTAL_1_LINK;
$getPortal2Link = PORTAL_2_LINK;
$getPortal3Link = PORTAL_3_LINK;
$getPortalLM = PORTAL_LOGO_MARGIN;
$getPortalLMM = PORTAL_LOGO_MARGIN_M;
$getPortalIM = PORTAL_IMAGE_MARGIN;
$getPortalIMM = PORTAL_IMAGE_MARGIN_M;
$getPortalLogoSize = PORTAL_LOGO_SIZE;
$getPortalLogoSizeM = PORTAL_LOGO_SIZE_M;
$getNavbarLogo = THEME_LOGO;
$getPageFavicon = THEME_FAVICON;
$getDiscordServer = THEME_DISCORD_SERVER;
$getAlertText = THEME_ALERT_TEXT;
$getAlertTitle = THEME_ALERT_TITLE;
$getDSBox = THEME_DS_BOX;
$getAnnounceText = THEME_ANNOUNCE_TEXT;
$getAnnounceTitle = THEME_ANNOUNCE_TITLE;
$getSlider1Title = THEME_SLIDER1_TITLE;
$getSlider1Desc = THEME_SLIDER1_DESCRIPTION;
$getSlider1Image = THEME_SLIDER1_IMAGE;
$getSlider1Link = THEME_SLIDER1_LINK;
$getSlider2Title = THEME_SLIDER2_TITLE;
$getSlider2Desc = THEME_SLIDER2_DESCRIPTION;
$getSlider2Image = THEME_SLIDER2_IMAGE;
$getSlider2Link = THEME_SLIDER2_LINK;
$getSlider3Title = THEME_SLIDER3_TITLE;
$getSlider3Desc = THEME_SLIDER3_DESCRIPTION;
$getSlider3Image = THEME_SLIDER3_IMAGE;
$getSlider3Link = THEME_SLIDER4_LINK;
$getSlider4Title = THEME_SLIDER4_TITLE;
$getSlider4Desc = THEME_SLIDER4_DESCRIPTION;
$getSlider4Image = THEME_SLIDER4_IMAGE;
$getSlider4Link = THEME_SLIDER4_LINK;
$getSlider5Title = THEME_SLIDER5_TITLE;
$getSlider5Desc = THEME_SLIDER5_DESCRIPTION;
$getSlider5Image = THEME_SLIDER5_IMAGE;
$getSlider5Link = THEME_SLIDER5_LINK;

$smarty->assign(array(
	'PARENT_PAGE' => PARENT_PAGE,
	'DASHBOARD' => $language->get('admin', 'dashboard'),
	'PAGE' => PANEL_PAGE,
	'TOKEN' => Token::get(),
	'SUBMIT' => $language->get('general', 'submit'),
	'FAVICON_VALUE' => $getPageFavicon,
	'HEADER_BG_VALUE' => $getNavbarBg,
	'LOGO_VALUE' => $getNavbarLogo,
	'GA_VALUE' => $getGA,
	'TS_VALUE' => $getTS,
	'AL_VALUE' => $getAL,
	'LINKS_VALUE' => $getLinks,
	'DARK_VALUE' => $getDark,
	'CARD_ROUNDED_VALUE' => $getCardRounded,
	'BG_HEIGHT_VALUE' => $getBGHeight,
	'BG_HEIGHT_M_VALUE' => $getBGHeightM,
	'NAVBAR_VALUE' => $getNavbar,
	'EBG_VALUE' => $getEBG,
	'LBG_VALUE' => $getLBG,
	'RBG_VALUE' => $getRBG,
	'ELR_LOGO_VALUE' => $getELRLogo,
	'ELR_MARGIN_VALUE' => $getELRMargin,
	'WB_S1_VALUE' => $getWBs1,
	'WB_S2_VALUE' => $getWBs2,
	'WB_S3_VALUE' => $getWBs3,
	'WB_S4_VALUE' => $getWBs4,
	'WB_S5_VALUE' => $getWBs5,
	'WB_S6_VALUE' => $getWBs6,
	'WB_T_VALUE' => $getWBt,
	'WB_D_VALUE' => $getWBd,
	'WB_1N_VALUE' => $getWB1n,
	'WB_1L_VALUE' => $getWB1l,
	'WB_2N_VALUE' => $getWB2n,
	'WB_2L_VALUE' => $getWB2l,
	'BOX_MARGIN_VALUE' => $getBoxMargin,
	'FONT_VALUE' => $getFont,
	'S_COLOR_VALUE' => $getS,
	'P_COLOR_VALUE' => $getP,
	'LOGO_SIZE_VALUE' => $getLogoSize,
	'LOGO_SIZE_M_VALUE' => $getLogoSizeM,
	'LOGO_MARGIN_VALUE' => $getLogoMargin,
	'LOGO_MARGIN_M_VALUE' => $getLogoMarginM,
	'COVERLAY_VALUE' => $getCOverlay,
	'PORTAL_BG_VALUE' => $getPortalBg,
	'PORTAL1_ICON_VALUE' => $getPortal1Icon,
	'PORTAL2_ICON_VALUE' => $getPortal2Icon,
	'PORTAL3_ICON_VALUE' => $getPortal3Icon,
	'PORTAL1_LINK_VALUE' => $getPortal1Link,
	'PORTAL2_LINK_VALUE' => $getPortal2Link,
	'PORTAL3_LINK_VALUE' => $getPortal3Link,
	'PORTAL_LOGO_VALUE' => $getPortalLogoSize,
	'PORTAL_LM_VALUE' => $getPortalLM,
	'PORTAL_LMM_VALUE' => $getPortalLMM,
	'PORTAL_IM_VALUE' => $getPortalIM,
	'PORTAL_IMM_VALUE' => $getPortalIMM,
	'PORTAL_LOGO_M_VALUE' => $getPortalLogoSizeM,
	'ALERT_TEXT_VALUE' => $getAlertText,
	'ALERT_TITLE_VALUE' => $getAlertTitle,
	'ANNOUNCE_TEXT_VALUE' => $getAnnounceText,
	'ANNOUNCE_TITLE_VALUE' => $getAnnounceTitle,
	'DS_BOX_VALUE' => $getDSBox,
	'ABOUT_VALUE' => $getAbout,
	'OTHER_T_VALUE' => $getOtherT,
	'OTHER_D_VALUE' => $getOtherD,
	'OTHER_BT_VALUE' => $getOtherBT,
	'OTHER_BL_VALUE' => $getOtherBL,
	'OTHER_BC_VALUE' => $getOtherBC,
	'OTHER_BCH_VALUE' => $getOtherBCH,
	'NEWS_BTN_VALUE' => $getNewsBTN,
	'NEWS_LINK_VALUE' => $getNewsLink,
	'DISCORD_SERVER_VALUE' => $getDiscordServer,
	'SLIDER1_TITLE_VALUE' => $getSlider1Title,
	'SLIDER1_DESC_VALUE' => $getSlider1Desc,
	'SLIDER1_IMAGE_VALUE' => $getSlider1Image,
	'SLIDER1_LINK_VALUE' => $getSlider1Link,
	'SLIDER2_TITLE_VALUE' => $getSlider2Title,
	'SLIDER2_DESC_VALUE' => $getSlider2Desc,
	'SLIDER2_IMAGE_VALUE' => $getSlider2Image,
	'SLIDER2_LINK_VALUE' => $getSlider2Link,
	'SLIDER3_TITLE_VALUE' => $getSlider3Title,
	'SLIDER3_DESC_VALUE' => $getSlider3Desc,
	'SLIDER3_IMAGE_VALUE' => $getSlider3Image,
	'SLIDER3_LINK_VALUE' => $getSlider3Link,
	'SLIDER4_TITLE_VALUE' => $getSlider4Title,
	'SLIDER4_DESC_VALUE' => $getSlider4Desc,
	'SLIDER4_IMAGE_VALUE' => $getSlider4Image,
	'SLIDER4_LINK_VALUE' => $getSlider4Link,
	'SLIDER5_TITLE_VALUE' => $getSlider5Title,
	'SLIDER5_DESC_VALUE' => $getSlider5Desc,
	'SLIDER5_IMAGE_VALUE' => $getSlider5Image,
	'SLIDER5_LINK_VALUE' => $getSlider5Link,
	'HOME' => $skyfall_language->get('language', 'home'),
	'GENERAL' => $skyfall_language->get('language', 'general'),
	'COLORS' => $skyfall_language->get('language', 'colors'),
	'HEADER' => $skyfall_language->get('language', 'header'),
	'WB' => $skyfall_language->get('language', 'wb'),
	'NEWS' => $skyfall_language->get('language', 'news'),
	'AA' => $skyfall_language->get('language', 'aa'),
	'SLIDER' => $skyfall_language->get('language', 'slider'),
	'ELR' => $skyfall_language->get('language', 'elr'),
	'FOOTER' => $skyfall_language->get('language', 'footer'),
	'PORTAL' => $skyfall_language->get('language', 'portal'),
	'UPDATE' => $skyfall_language->get('language', 'update'),
	'TS_PANEL' => $skyfall_language->get('language', 'ts_panel'),
	'TS_WIDGET' => $skyfall_language->get('language', 'ts_widget'),
	'TS_US' => $skyfall_language->get('language', 'ts_us'),
	'TS_NODISPLAY' => $skyfall_language->get('language', 'ts_nodisplay'),
	'BG_TAB' => $skyfall_language->get('language', 'bg_tab'),
	'LOGO_TAB' => $skyfall_language->get('language', 'logo_tab'),
	'HOME_1' => $skyfall_language->get('language', 'home_1'),
	'HOME_2' => $skyfall_language->get('language', 'home_2'),
	'HOME_3' => $skyfall_language->get('language', 'home_3'),
	'UPDATE_1' => $skyfall_language->get('language', 'update_1'),
	'UPDATE_2' => $skyfall_language->get('language', 'update_2'),
	'UPDATE_3' => $skyfall_language->get('language', 'update_3'),
	'UPDATE_4' => $skyfall_language->get('language', 'update_4'),
	'UPDATE_5' => $skyfall_language->get('language', 'update_5'),
	'UPDATE_6' => $skyfall_language->get('language', 'update_6'),
	'FONT_1' => $skyfall_language->get('language', 'font_1'),
	'FONT_2' => $skyfall_language->get('language', 'font_2'),
	'P_COLOR_1' => $skyfall_language->get('language', 'p_color_1'),
	'S_COLOR_1' => $skyfall_language->get('language', 's_color_1'),
	'DS_TEXTS_TAB' => $skyfall_language->get('language', 'ds_texts_tab'),
	'NAVBAR_1' => $skyfall_language->get('language', 'navbar_1'),
	'NAVBAR_2' => $skyfall_language->get('language', 'navbar_2'),
	'NAVBAR_3' => $skyfall_language->get('language', 'navbar_3'),
	'COVERLAY_1' => $skyfall_language->get('language', 'coverlay_1'),
	'DISCORD_SERVER_1' => $skyfall_language->get('language', 'discord_server_1'),
	'BUTTONS_TAB' => $skyfall_language->get('language', 'buttons_tab'),
	'SKINS_TAB' => $skyfall_language->get('language', 'skins_tab'),
	'WB_T_1' => $skyfall_language->get('language', 'wb_t_1'),
	'NEWS_LINK_1' => $skyfall_language->get('language', 'news_link_1'),
	'ALERT' => $skyfall_language->get('language', 'alert'),
	'ANNOUNCEMENT' => $skyfall_language->get('language', 'announcement'),
	'ALERT_1' => $skyfall_language->get('language', 'alert_1'),
	'ANNOUNCEMENT_1' => $skyfall_language->get('language', 'announcement_1'),
	'SLIDER1' => $skyfall_language->get('language', 'slider1'),
	'SLIDER2' => $skyfall_language->get('language', 'slider2'),
	'SLIDER3' => $skyfall_language->get('language', 'slider3'),
	'SLIDER4' => $skyfall_language->get('language', 'slider4'),
	'SLIDER5' => $skyfall_language->get('language', 'slider5'),
	'BLANK' => $skyfall_language->get('language', 'blank'),
	'SLIDER1_1' => $skyfall_language->get('language', 'slider1_1'),
	'SLIDER2_1' => $skyfall_language->get('language', 'slider2_1'),
	'SLIDER3_1' => $skyfall_language->get('language', 'slider3_1'),
	'SLIDER4_1' => $skyfall_language->get('language', 'slider4_1'),
	'SLIDER5_1' => $skyfall_language->get('language', 'slider5_1'),
	'BACKGROUNDS_TAB' => $skyfall_language->get('language', 'backgrounds_tab'),
	'ABOUT_SECTION_TAB' => $skyfall_language->get('language', 'about_section_tab'),
	'OTHER_SECTION_TAB' => $skyfall_language->get('language', 'other_section_tab'),
	'IMAGE1_TAB' => $skyfall_language->get('language', 'image1_tab'),
	'IMAGE2_TAB' => $skyfall_language->get('language', 'image2_tab'),
	'IMAGE3_TAB' => $skyfall_language->get('language', 'image3_tab'),
	'FAVICON' => $skyfall_language->get('language', 'favicon'),
	'HEADER_BG' => $skyfall_language->get('language', 'header_bg'),
	'LOGO' => $skyfall_language->get('language', 'logo'),
	'GA' => $skyfall_language->get('language', 'ga'),
	'DARK' => $skyfall_language->get('language', 'dark'),
	'LINKS' => $skyfall_language->get('language', 'links'),
	'LINKS_WGH' => $skyfall_language->get('language', 'links_wgh'),
	'LINKS_GWH' => $skyfall_language->get('language', 'links_gwh'),
	'CARD_ROUNDED' => $skyfall_language->get('language', 'card_rounded'),
	'BG_HEIGHT' => $skyfall_language->get('language', 'bg_height'),
	'BG_HEIGHT_M' => $skyfall_language->get('language', 'bg_height_m'),
	'NAVBAR' => $skyfall_language->get('language', 'navbar'),
	'EBG' => $skyfall_language->get('language', 'ebg'),
	'LBG' => $skyfall_language->get('language', 'lbg'),
	'RBG' => $skyfall_language->get('language', 'rbg'),
	'ELR_LOGO' => $skyfall_language->get('language', 'elr_logo'),
	'ELR_MARGIN' => $skyfall_language->get('language', 'elr_margin'),
	'WB_S1' => $skyfall_language->get('language', 'wb_s1'),
	'WB_S2' => $skyfall_language->get('language', 'wb_s2'),
	'WB_S3' => $skyfall_language->get('language', 'wb_s3'),
	'WB_S4' => $skyfall_language->get('language', 'wb_s4'),
	'WB_S5' => $skyfall_language->get('language', 'wb_s5'),
	'WB_S6' => $skyfall_language->get('language', 'wb_s6'),
	'WB_T' => $skyfall_language->get('language', 'wb_t'),
	'WB_D' => $skyfall_language->get('language', 'wb_d'),
	'WB_1N' => $skyfall_language->get('language', 'wb_1n'),
	'WB_1L' => $skyfall_language->get('language', 'wb_1l'),
	'WB_2N' => $skyfall_language->get('language', 'wb_2n'),
	'WB_2L' => $skyfall_language->get('language', 'wb_2l'),
	'BOX_MARGIN' => $skyfall_language->get('language', 'box_margin'),
	'FONT' => $skyfall_language->get('language', 'font'),
	'S_COLOR' => $skyfall_language->get('language', 's_color'),
	'P_COLOR' => $skyfall_language->get('language', 'p_color'),
	'LOGO_SIZE' => $skyfall_language->get('language', 'logo_size'),
	'LOGO_SIZE_M' => $skyfall_language->get('language', 'logo_size_m'),
	'LOGO_MARGIN' => $skyfall_language->get('language', 'logo_margin'),
	'LOGO_MARGIN_M' => $skyfall_language->get('language', 'logo_margin_m'),
	'COVERLAY' => $skyfall_language->get('language', 'coverlay'),
	'PORTAL_BG' => $skyfall_language->get('language', 'portal_bg'),
	'PORTAL1_ICON' => $skyfall_language->get('language', 'portal1_icon'),
	'PORTAL2_ICON' => $skyfall_language->get('language', 'portal2_icon'),
	'PORTAL3_ICON' => $skyfall_language->get('language', 'portal3_icon'),
	'PORTAL1_LINK' => $skyfall_language->get('language', 'portal1_link'),
	'PORTAL2_LINK' => $skyfall_language->get('language', 'portal2_link'),
	'PORTAL3_LINK' => $skyfall_language->get('language', 'portal3_link'),
	'PORTAL_LOGO' => $skyfall_language->get('language', 'portal_logo'),
	'PORTAL_LM' => $skyfall_language->get('language', 'portal_lm'),
	'PORTAL_LMM' => $skyfall_language->get('language', 'portal_lmm'),
	'PORTAL_IM' => $skyfall_language->get('language', 'portal_im'),
	'PORTAL_IMM' => $skyfall_language->get('language', 'portal_imm'),
	'PORTAL_LOGO_M' => $skyfall_language->get('language', 'portal_logo_m'),
	'ALERT_TEXT' => $skyfall_language->get('language', 'alert_text'),
	'ALERT_TITLE' => $skyfall_language->get('language', 'alert_title'),
	'ANNOUNCE_TEXT' => $skyfall_language->get('language', 'announce_text'),
	'ANNOUNCE_TITLE' => $skyfall_language->get('language', 'announce_title'),
	'DS_BOX' => $skyfall_language->get('language', 'ds_box'),
	'ABOUT' => $skyfall_language->get('language', 'about'),
	'OTHER_T' => $skyfall_language->get('language', 'other_t'),
	'OTHER_D' => $skyfall_language->get('language', 'other_d'),
	'OTHER_BT' => $skyfall_language->get('language', 'other_bt'),
	'OTHER_BL' => $skyfall_language->get('language', 'other_bl'),
	'OTHER_BC' => $skyfall_language->get('language', 'other_bc'),
	'OTHER_BCH' => $skyfall_language->get('language', 'other_bch'),
	'NEWS_BTN' => $skyfall_language->get('language', 'news_btn'),
	'NEWS_LINK' => $skyfall_language->get('language', 'news_link'),
	'DISCORD_SERVER' => $skyfall_language->get('language', 'discord_server'),
	'SLIDER1_TITLE' => $skyfall_language->get('language', 'slider1_title'),
	'SLIDER1_DESC' => $skyfall_language->get('language', 'slider1_desc'),
	'SLIDER1_IMAGE' => $skyfall_language->get('language', 'slider1_image'),
	'SLIDER1_LINK' => $skyfall_language->get('language', 'slider1_link'),
	'SLIDER2_TITLE' => $skyfall_language->get('language', 'slider2_title'),
	'SLIDER2_DESC' => $skyfall_language->get('language', 'slider2_desc'),
	'SLIDER2_IMAGE' => $skyfall_language->get('language', 'slider2_image'),
	'SLIDER2_LINK' => $skyfall_language->get('language', 'slider2_link'),
	'SLIDER3_TITLE' => $skyfall_language->get('language', 'slider3_title'),
	'SLIDER3_DESC' => $skyfall_language->get('language', 'slider3_desc'),
	'SLIDER3_IMAGE' => $skyfall_language->get('language', 'slider3_image'),
	'SLIDER3_LINK' => $skyfall_language->get('language', 'slider3_link'),
	'SLIDER4_TITLE' => $skyfall_language->get('language', 'slider4_title'),
	'SLIDER4_DESC' => $skyfall_language->get('language', 'slider4_desc'),
	'SLIDER4_IMAGE' => $skyfall_language->get('language', 'slider4_image'),
	'SLIDER4_LINK' => $skyfall_language->get('language', 'slider4_link'),
	'SLIDER5_TITLE' => $skyfall_language->get('language', 'slider5_title'),
	'SLIDER5_DESC' => $skyfall_language->get('language', 'slider5_desc'),
	'SLIDER5_IMAGE' => $skyfall_language->get('language', 'slider5_image'),
	'SLIDER5_LINK' => $skyfall_language->get('language', 'slider5_link'),
	'SKYFALL' => $skyfall_language->get('language', 'skyfall_title'),
	'YES' => $skyfall_language->get('language', 'yes'),
	'NO' => $skyfall_language->get('language', 'no'),
	'AL' => $skyfall_language->get('language', 'al'),
));

$page_load = microtime(true) - $start;
define('PAGE_LOAD_TIME', str_replace('{x}', round($page_load, 3), $language->get('general', 'page_loaded_in')));

$template->onPageLoad();

require(ROOT_PATH . '/core/templates/panel_navbar.php');

$template->displayTemplate('skyfall/index.tpl', $smarty);