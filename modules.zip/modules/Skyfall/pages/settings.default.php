<?php
$settings_inf="<?php

	if(!defined('THEME_GA'))
	define('THEME_GA', '".$getGA."');

	if(!defined('THEME_AL'))
	define('THEME_AL', '".$getAL."');

	if(!defined('THEME_LINKS'))
	define('THEME_LINKS', '".$getLinks."');

	if(!defined('THEME_TS'))
	define('THEME_TS', '".$getTS."');

	if(!defined('THEME_DARK'))
	define('THEME_DARK', '".$getDark."');

	if(!defined('THEME_CARD_ROUNDED'))
	define('THEME_CARD_ROUNDED', '".$getCardRounded."');

	if(!defined('THEME_BG_HEIGHT'))
	define('THEME_BG_HEIGHT', '".$getBGHeight."');

	if(!defined('THEME_BG_HEIGHT_M'))
	define('THEME_BG_HEIGHT_M', '".$getBGHeightM."');

	if(!defined('THEME_NAVBAR'))
	define('THEME_NAVBAR', '".$getNavbar."');

	if(!defined('THEME_L_BG'))
	define('THEME_L_BG', '".$getLBG."');

	if(!defined('THEME_E_BG'))
	define('THEME_E_BG', '".$getEBG."');

	if(!defined('THEME_R_BG'))
	define('THEME_R_BG', '".$getRBG."');

	if(!defined('THEME_ELR_LOGO'))
	define('THEME_ELR_LOGO', '".$getELRLogo."');

	if(!defined('THEME_ELR_MARGIN'))
	define('THEME_ELR_MARGIN', '".$getELRMargin."');

	if(!defined('THEME_WB_S1'))
	define('THEME_WB_S1', '".$getWBs1."');

	if(!defined('THEME_WB_S2'))
	define('THEME_WB_S2', '".$getWBs2."');

	if(!defined('THEME_WB_S3'))
	define('THEME_WB_S3', '".$getWBs3."');

	if(!defined('THEME_WB_S4'))
	define('THEME_WB_S4', '".$getWBs4."');

	if(!defined('THEME_WB_S5'))
	define('THEME_WB_S5', '".$getWBs5."');

	if(!defined('THEME_WB_S6'))
	define('THEME_WB_S6', '".$getWBs6."');

	if(!defined('THEME_WB_T'))
	define('THEME_WB_T', '".$getWBt."');

	if(!defined('THEME_WB_D'))
	define('THEME_WB_D', '".$getWBd."');

	if(!defined('THEME_WB_1N'))
	define('THEME_WB_1N', '".$getWB1n."');

	if(!defined('THEME_WB_2N'))
	define('THEME_WB_2N', '".$getWB2n."');

	if(!defined('THEME_WB_1L'))
	define('THEME_WB_1L', '".$getWB1l."');

	if(!defined('THEME_WB_2L'))
	define('THEME_WB_2L', '".$getWB2l."');

	if(!defined('THEME_ABOUT'))
	define('THEME_ABOUT', '".$getAbout."');

	if(!defined('THEME_OTHER_T'))
	define('THEME_OTHER_T', '".$getOtherT."');

	if(!defined('THEME_OTHER_D'))
	define('THEME_OTHER_D', '".$getOtherD."');

	if(!defined('THEME_OTHER_BT'))
	define('THEME_OTHER_BT', '".$getOtherBT."');

	if(!defined('THEME_OTHER_BL'))
	define('THEME_OTHER_BL', '".$getOtherBL."');

	if(!defined('THEME_OTHER_BC'))
	define('THEME_OTHER_BC', '".$getOtherBC."');

	if(!defined('THEME_OTHER_BCH'))
	define('THEME_OTHER_BCH', '".$getOtherBCH."');

	if(!defined('THEME_NEWS_BTN'))
	define('THEME_NEWS_BTN', '".$getNewsBTN."');

	if(!defined('THEME_NEWS_LINK'))
	define('THEME_NEWS_LINK', '".$getNewsLink."');

	if(!defined('THEME_LOGO_SIZE'))
	define('THEME_LOGO_SIZE', '".$getLogoSize."');

	if(!defined('THEME_LOGO_SIZE_M'))
	define('THEME_LOGO_SIZE_M', '".$getLogoSizeM."');

	if(!defined('THEME_LOGO_MARGIN'))
	define('THEME_LOGO_MARGIN', '".$getLogoMargin."');

	if(!defined('THEME_LOGO_MARGIN_M'))
	define('THEME_LOGO_MARGIN_M', '".$getLogoMarginM."');

	if(!defined('THEME_C_OVERLAY'))
	define('THEME_C_OVERLAY', '".$getCOverlay."');

	if(!defined('THEME_FONT'))
	define('THEME_FONT', '".$getFont."');

	if(!defined('THEME_BOX_MARGIN'))
	define('THEME_BOX_MARGIN', '".$getBoxMargin."');

	if(!defined('THEME_P_COLOR'))
	define('THEME_P_COLOR', '".$getP."');

	if(!defined('THEME_S_COLOR'))
	define('THEME_S_COLOR', '".$getS."');
	
	if(!defined('THEME_DISCORD_SERVER'))
	define('THEME_DISCORD_SERVER', '".$getDiscordServer."');

	if(!defined('THEME_BG'))
	define('THEME_BG', '".$getBG."');

	if(!defined('THEME_ALERT_TITLE'))
	define('THEME_ALERT_TITLE', '".$getAlertTitle."');
	
	if(!defined('THEME_ALERT_TEXT'))
	define('THEME_ALERT_TEXT', '".$getAlertText."');
	
	if(!defined('THEME_ANNOUNCE_TITLE'))
	define('THEME_ANNOUNCE_TITLE', '".$getAnnounceTitle."');
	
	if(!defined('THEME_ANNOUNCE_TEXT'))
	define('THEME_ANNOUNCE_TEXT', '".$getAnnounceText."');
	
	if(!defined('THEME_FAVICON'))
	define('THEME_FAVICON', '".$getFavicon."');

	if(!defined('THEME_DS_BOX'))
	define('THEME_DS_BOX', '".$getDSBox."');

	if(!defined('THEME_LOGO'))
	define('THEME_LOGO', '".$getLOGO."');
	
	if(!defined('THEME_SLIDER1_TITLE'))
	define('THEME_SLIDER1_TITLE', '".$getSlider1Title."');
	
	if(!defined('THEME_SLIDER2_TITLE'))
	define('THEME_SLIDER2_TITLE', '".$getSlider2Title."');
	
	if(!defined('THEME_SLIDER3_TITLE'))
	define('THEME_SLIDER3_TITLE', '".$getSlider3Title."');
	
	if(!defined('THEME_SLIDER4_TITLE'))
	define('THEME_SLIDER4_TITLE', '".$getSlider4Title."');
	
	if(!defined('THEME_SLIDER5_TITLE'))
	define('THEME_SLIDER5_TITLE', '".$getSlider5Title."');
	
	if(!defined('THEME_SLIDER1_DESCRIPTION'))
	define('THEME_SLIDER1_DESCRIPTION', '".$getSlider1Desc."');
	
	if(!defined('THEME_SLIDER2_DESCRIPTION'))
	define('THEME_SLIDER2_DESCRIPTION', '".$getSlider2Desc."');
	
	if(!defined('THEME_SLIDER3_DESCRIPTION'))
	define('THEME_SLIDER3_DESCRIPTION', '".$getSlider3Desc."');
	
	if(!defined('THEME_SLIDER4_DESCRIPTION'))
	define('THEME_SLIDER4_DESCRIPTION', '".$getSlider4Desc."');
	
	if(!defined('THEME_SLIDER5_DESCRIPTION'))
	define('THEME_SLIDER5_DESCRIPTION', '".$getSlider5Desc."');
	
	if(!defined('THEME_SLIDER1_IMAGE'))
	define('THEME_SLIDER1_IMAGE', '".$getSlider1Image."');
	
	if(!defined('THEME_SLIDER2_IMAGE'))
	define('THEME_SLIDER2_IMAGE', '".$getSlider2Image."');
	
	if(!defined('THEME_SLIDER3_IMAGE'))
	define('THEME_SLIDER3_IMAGE', '".$getSlider3Image."');
	
	if(!defined('THEME_SLIDER4_IMAGE'))
	define('THEME_SLIDER4_IMAGE', '".$getSlider4Image."');
	
	if(!defined('THEME_SLIDER5_IMAGE'))
	define('THEME_SLIDER5_IMAGE', '".$getSlider5Image."');
	
	if(!defined('THEME_SLIDER1_LINK'))
	define('THEME_SLIDER1_LINK', '".$getSlider1Link."');
	
	if(!defined('THEME_SLIDER2_LINK'))
	define('THEME_SLIDER2_LINK', '".$getSlider2Link."');
	
	if(!defined('THEME_SLIDER3_LINK'))
	define('THEME_SLIDER3_LINK', '".$getSlider3Link."');
	
	if(!defined('THEME_SLIDER4_LINK'))
	define('THEME_SLIDER4_LINK', '".$getSlider4Link."');
	
	if(!defined('THEME_SLIDER5_LINK'))
	define('THEME_SLIDER5_LINK', '".$getSlider5Link."');
	
	if(!defined('PORTAL_1_LINK'))
	define('PORTAL_1_LINK', '".$getPortal1Link."');
	
	if(!defined('PORTAL_2_LINK'))
	define('PORTAL_2_LINK', '".$getPortal2Link."');
	
	if(!defined('PORTAL_3_LINK'))
	define('PORTAL_3_LINK', '".$getPortal3Link."');
	
	if(!defined('PORTAL_1_ICON'))
	define('PORTAL_1_ICON', '".$getPortal1Icon."');
	
	if(!defined('PORTAL_2_ICON'))
	define('PORTAL_2_ICON', '".$getPortal2Icon."');
	
	if(!defined('PORTAL_3_ICON'))
	define('PORTAL_3_ICON', '".$getPortal3Icon."');

	if(!defined('PORTAL_LOGO_SIZE'))
	define('PORTAL_LOGO_SIZE', '".$getPortalLogoSize."');

	if(!defined('PORTAL_LOGO_SIZE_M'))
	define('PORTAL_LOGO_SIZE_M', '".$getPortalLogoSizeM."');

	if(!defined('PORTAL_LOGO_MARGIN'))
	define('PORTAL_LOGO_MARGIN', '".$getPortalLM."');

	if(!defined('PORTAL_LOGO_MARGIN_M'))
	define('PORTAL_LOGO_MARGIN_M', '".$getPortalLMM."');

	if(!defined('PORTAL_IMAGE_MARGIN'))
	define('PORTAL_IMAGE_MARGIN', '".$getPortalIM."');

	if(!defined('PORTAL_IMAGE_MARGIN_M'))
	define('PORTAL_IMAGE_MARGIN_M', '".$getPortalIMM."');
	
	if(!defined('THEME_PORTAL_BG'))
	define('THEME_PORTAL_BG', '".$getPortalBg."');

?>";
?>