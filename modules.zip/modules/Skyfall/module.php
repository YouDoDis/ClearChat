<?php 
/*
 *	Made by Coldfire - https://coldfiredev.cf
 *  NamelessMC version 2.0.0-pr7
 *
 *  Module for Skyfall Template
 */

class Skyfall_Module extends Module {
	private $_language, $_skyfall_language;
	public function __construct($pages, $language, $skyfall_language){
		$this->_language = $language;
		$this->_skyfall_language = $skyfall_language;
		$name = 'Skyfall';
		$author = '<a href="https://coldfiredev.cf" target="_blank" rel="nofollow noopener">Coldfire</a>';
		$module_version = '1.3.0';
		$nameless_version = '2.0.0-pr7';
		parent::__construct($this, $name, $author, $module_version, $nameless_version);
		$pages->add('Skyfall', '/panel/skyfall', 'pages/panel.php');
	}
	public function onInstall(){
		// Copy panel template
		if(!is_dir(ROOT_PATH . '/custom/panel_templates/' . PANEL_TEMPLATE . '/skyfall')){
			try {
				mkdir(ROOT_PATH . '/custom/panel_templates/' . PANEL_TEMPLATE . '/skyfall');
				copy(ROOT_PATH . '/custom/panel_templates/Default/skyfall/index.tpl', ROOT_PATH . '/custom/panel_templates/' . PANEL_TEMPLATE . '/skyfall/index.tpl');
			} catch(Exception $e){
				// Unable to copy
			}
		}
	}
	public function onUninstall(){
		// Not necessary
	}
	public function onEnable(){
		// Not necessary
	}
	public function onDisable(){
		// Not necessary
	}
	public function onPageLoad($user, $pages, $cache, $smarty, $navs, $widgets, $template){
		PermissionHandler::registerPermissions('Skyfall', array(
			'admincp.skyfall' => $this->_language->get('moderator', 'staff_cp') . ' &raquo; Skyfall'
		));
		if(defined('FRONT_END')){
			require(ROOT_PATH . '/modules/Skyfall/pages/getvariables.php');
			$smarty->assign(array(
				'DISCORD_BOX_COPY' => $this->_skyfall_language->get('language', 'discord_box_copy'),
				'MENU' => $this->_skyfall_language->get('language', 'menu'),
				'TS_TITLE' => $this->_skyfall_language->get('language', 'ts_title'),
				'TS_BUTTON' => $this->_skyfall_language->get('language', 'ts_button'),
				'SERVER_BOX_TITLE' => $this->_skyfall_language->get('language', 'server_box_title'),
				'NEWS_BUTTON' => $this->_skyfall_language->get('language', 'news_button'),
				'NEWS_ERROR_TITLE' => $this->_skyfall_language->get('language', 'news_error_title'),
				'NEWS_ERROR_DESC' => $this->_skyfall_language->get('language', 'news_error_desc'),
				'ABOUT_TITLE' => $this->_skyfall_language->get('language', 'about_title'),
				'DISCORD_BOX_STATUS_1' => $this->_skyfall_language->get('language', 'discord_box_status_1'),
				'DISCORD_BOX_STATUS_2' => $this->_skyfall_language->get('language', 'discord_box_status_2'),
				'DISCORD_BOX_TITLE' => $this->_skyfall_language->get('language', 'discord_box_title'),
				'FOOTER_CREDIT_1' => $this->_skyfall_language->get('language', 'footer_credit_1'),
				'FOOTER_CREDIT_2' => $this->_skyfall_language->get('language', 'footer_credit_2'),
				'THEME_CARD_ROUNDED' => $theme_card_rounded,
				'THEME_DARK' => $theme_dark,
				'THEME_LINKS' => $theme_links,
				'THEME_TS' => $theme_ts,
				'THEME_AL' => $theme_al,
				'THEME_BG_HEIGHT' => $theme_bg_height,
				'THEME_BG_HEIGHT_M' => $theme_bg_height_m,
				'THEME_NAVBAR' => $theme_navbar,
				'THEME_SLIDER1_TITLE' => $theme_slider_1_title,
				'THEME_SLIDER2_TITLE' => $theme_slider_2_title,
				'THEME_SLIDER3_TITLE' => $theme_slider_3_title,
				'THEME_SLIDER4_TITLE' => $theme_slider_4_title,
				'THEME_SLIDER5_TITLE' => $theme_slider_5_title,
				'THEME_SLIDER1_DESCRIPTION' => $theme_slider_1_description,
				'THEME_SLIDER2_DESCRIPTION' => $theme_slider_2_description,
				'THEME_SLIDER3_DESCRIPTION' => $theme_slider_3_description,
				'THEME_SLIDER4_DESCRIPTION' => $theme_slider_4_description,
				'THEME_SLIDER5_DESCRIPTION' => $theme_slider_5_description,
				'THEME_SLIDER1_IMAGE' => $theme_slider_1_image,
				'THEME_SLIDER2_IMAGE' => $theme_slider_2_image,
				'THEME_SLIDER3_IMAGE' => $theme_slider_3_image,
				'THEME_SLIDER4_IMAGE' => $theme_slider_4_image,
				'THEME_SLIDER5_IMAGE' => $theme_slider_5_image,
				'THEME_SLIDER1_LINK' => $theme_slider_1_link,
				'THEME_SLIDER2_LINK' => $theme_slider_2_link,
				'THEME_SLIDER3_LINK' => $theme_slider_3_link,
				'THEME_SLIDER4_LINK' => $theme_slider_4_link,
				'THEME_SLIDER5_LINK' => $theme_slider_5_link,
				'THEME_WB_S1' => $theme_wb_s1,
				'THEME_WB_S2' => $theme_wb_s2,
				'THEME_WB_S3' => $theme_wb_s3,
				'THEME_WB_S4' => $theme_wb_s4,
				'THEME_WB_S5' => $theme_wb_s5,
				'THEME_WB_S6' => $theme_wb_s6,
				'THEME_WB_T' => $theme_wb_t,
				'THEME_WB_D' => $theme_wb_d,
				'THEME_WB_1N' => $theme_wb_1n,
				'THEME_WB_2N' => $theme_wb_2n,
				'THEME_WB_1L' => $theme_wb_1l,
				'THEME_WB_2L' => $theme_wb_2l,
				'THEME_L_BG' => $theme_l_bg,
				'THEME_R_BG' => $theme_r_bg,
				'THEME_E_BG' => $theme_e_bg,
				'THEME_ELR_LOGO' => $theme_elr_logo,
				'THEME_ELR_MARGIN' => $theme_elr_margin,
				'PORTAL_1_LINK' => $portal1link,
				'PORTAL_2_LINK' => $portal2link,
				'PORTAL_3_LINK' => $portal3link,
				'PORTAL_1_ICON' => $portal1icon,
				'PORTAL_2_ICON' => $portal2icon,
				'PORTAL_3_ICON' => $portal3icon,
				'PORTAL_LOGO_SIZE' => $portallogo,
				'PORTAL_LOGO_MARGIN' => $portal_logo_margin,
				'PORTAL_LOGO_MARGIN_M' => $portal_logo_margin_m,
				'PORTAL_IMAGE_MARGIN' => $portal_image_margin,
				'PORTAL_IMAGE_MARGIN_M' => $portal_image_margin_m,
				'THEME_ABOUT' => $theme_about,
				'THEME_OTHER_T' => $theme_other_t,
				'THEME_OTHER_D' => $theme_other_d,
				'THEME_OTHER_BT' => $theme_other_bt,
				'THEME_OTHER_BL' => $theme_other_bl,
				'THEME_OTHER_BC' => $theme_other_bc,
				'THEME_OTHER_BCH' => $theme_other_bch,
				'THEME_NEWS_BTN' => $theme_news_btn,
				'THEME_NEWS_LINK' => $theme_news_link,
				'PORTAL_LOGO_SIZE_M' => $portallogom,
				'THEME_PORTAL_BG' => $theme_portal_bg,
				'THEME_DISCORD_SERVER' => $theme_discord_server,
				'THEME_FAVICON' => $theme_favicon,
				'THEME_LOGO' => $theme_logo,
				'THEME_BOX_MARGIN' => $theme_box_margin,
				'THEME_ALERT_TITLE' => $theme_alert_title,
				'THEME_ALERT_TEXT' => $theme_alert_text,
				'THEME_DS_BOX' => $theme_ds_box,
				'THEME_FONT' => $theme_font,
				'THEME_GA' => $theme_ga,
				'THEME_C_OVERLAY' => $theme_c_overlay,
				'THEME_P_COLOR' => $theme_p_color,
				'THEME_S_COLOR' => $theme_s_color,
				'THEME_LOGO_SIZE' => $theme_logo_size,
				'THEME_LOGO_SIZE_M' => $theme_logo_size_m,
				'THEME_LOGO_MARGIN' => $theme_logo_margin,
				'THEME_LOGO_MARGIN_M' => $theme_logo_margin_m,
				'THEME_ANNOUNCE_TITLE' => $theme_announce_title,
				'THEME_ANNOUNCE_TEXT' => $theme_announce_text
			));

		} else {
			if($user->data()->group_id == 2 || $user->hasPermission('admincp.skyfall')){
				$cache->setCache('panel_sidebar');
				if(!$cache->isCached('skyfall_order')){
					$order = 35;
					$cache->store('skyfall_order', 35);
				} else {
					$order = $cache->retrieve('skyfall_order');
				}
				if(!$cache->isCached('skyfall_icon')){
					$icon = '<i class="fas fa-palette"></i>';
					$cache->store('skyfall_icon', $icon);
				} else
					$icon = $cache->retrieve('skyfall_icon');

				$navs[2]->add('skyfall_divider', mb_strtoupper($this->_skyfall_language->get('language', 'skyfall_title')), 'divider', 'top', null, $order, '');
				$navs[2]->add('skyfall', $this->_skyfall_language->get('language', 'skyfall_title'), URL::build('/panel/skyfall'), 'top', null, ($order + 0.1), $icon);
			}
		}
	}
}